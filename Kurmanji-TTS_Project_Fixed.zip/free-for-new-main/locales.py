# Copyright (c) 2026 Kurmanji-TTS Team (University of Rojava)
# SPDX-License-Identifier: MIT

"""UI translations for Kurmanji-TTS (Arabic / Kurmanji / English).

Every language maps the same keys, in the same order, grouped as:
window chrome, counters, editor, engine, voice controls, player, window
actions, errors and status, validation, then the settings-dialog fragments.
The suite checks that the three key sets stay identical, so a new string must
be added to all three dictionaries in the same group.
"""

from __future__ import annotations

from typing import Dict

SUPPORTED_LANGUAGES = ("ar", "ku", "en")
RTL_LANGUAGES = ("ar",)

TRANSLATIONS: Dict[str, Dict[str, str]] = {
    "ar": {
        # ------------------------------------------------------ window chrome
        "app_subtitle": "تحويل النص الكورمانجي إلى كلام - محلي بالكامل (CPU)",
        "model_checking": "جاري فحص النموذج...",
        "model_ready": "النموذج جاهز",
        "model_not_ready": "النموذج أو المحرك غير جاهز",
        "close_notification": "إغلاق التنبيه",
        # ----------------------------------------------------------- counters
        "label_chars": "الأحرف:",
        "label_words": "الكلمات:",
        "label_hawar": "حروف Hawar المكتشفة:",
        "label_samples": "أمثلة نصية سريعة:",
        "clear_text": "مسح النص",
        "input_label": "Nivîsa Kurmancî (النص الكورمانجي)",
        "input_hint": "Mînak: Rojbaş! Ez dixwazim bi zimanê kurdî biaxivim...",
        "voice_language": "لغة النطق",
        "voice_language_tooltip": "اختر لغة النطق: الكورمانجية أو العربية",
        "input_label_ar": "النص العربي",
        "input_hint_ar": "اكتب نصاً عربياً: مرحباً، كيف حالك؟",
        # ------------------------------------------------------------- engine
        "engine_profile": "محرك النطق",
        "engine_profile_tooltip": "اختر محرك التوليد ونموذج اللغة",
        "profile_piper_kmr": "Kurmancî — Piper (90 Speakers)",
        "profile_mms_kmr": "Kurmancî — Meta MMS",
        "profile_mms_ara": "العربية — Meta MMS",
        "mms_speaker_0": "MMS Speaker 0",
        "mms_arabic": "MMS Arabic",
        "err_sherpa_missing": "مكتبة sherpa-onnx غير مثبتة: {error}",
        "err_sherpa_init": "تعذّر تحميل نموذج MMS: {error}",
        "speaker": "المتحدث",
        "speed": "السرعة:",
        "speed_tooltip": "سرعة النطق (0.50x بطيء — 1.50x سريع)",
        "generate": "توليد الصوت",
        "play": "تشغيل",
        "pause": "إيقاف مؤقت",
        "stop": "إيقاف",
        "save_wav": "حفظ WAV",
        # ------------------------------------------------------------- player
        "metric_gen": "زمن التوليد:",
        "metric_duration": "مدة الصوت:",
        "metric_rtf": "\u2066RTF\u2069:",
        "metric_rate": "التردد:",
        "metric_speaker": "المتحدث:",
        "language": "اللغة",
        "theme_tooltip": "تبديل الوضع الداكن / الفاتح",
        "settings_tooltip": "إعدادات النموذج والمحرك",
        "error_no_audio": "لا يوجد ملف صوتي جاهز للتشغيل.",
        "error_play": "تعذّر تشغيل الصوت داخل التطبيق: {error}",
        "error_seek": "تعذّر تحريك موضع الصوت: {error}",
        "error_save_first": "يرجى توليد الصوت أولاً قبل الحفظ.",
        "save_dialog_title": "حفظ الملف الصوتي (WAV)",
        "save_ok": "تم حفظ الملف الصوتي بنجاح: {name}",
        "save_failed": "فشل حفظ ملف WAV: {error}",
        "engine_hint": "تأكد من تشغيل setup_runtime.py أو ضبط المسارات من زر الإعدادات.",
        "load_in_app_failed": "تعذّر تحميل الصوت في المشغل الداخلي: {error}",
        "generate_ok": "تم توليد الصوت بنجاح!",
        "generate_failed": "حدث خطأ غير متوقع أثناء التوليد: {error}",
        "settings_title": "إعدادات \u2066Kurmanji-TTS\u2069",
        "model_path_label": "مسار ملف النموذج \u2066(.onnx)\u2069",
        "piper_path_label": "مسار محرك \u2066Piper\u2069 التنفيذي",
        "pick_model": "اختر ملف النموذج (.onnx)",
        "pick_piper": "اختر ملف Piper التنفيذي",
        "browse_model": "استعراض ملف النموذج",
        "browse_piper": "استعراض محرك Piper",
        "persistent": "إبقاء النموذج محمّلاً في الذاكرة (توليد أسرع دون إعادة تحميل)",
        "settings_note": "ملاحظة: يعمل التطبيق محلياً بالكامل على المعالج \u2066(CPU)\u2069 دون اتصال بالإنترنت.",
        "cancel": "إلغاء",
        "save_settings": "حفظ الإعدادات",
        # --------------------------------------------------- errors and status
        "err_model_missing": "ملف النموذج غير موجود: {path}",
        "err_config_missing": "ملف إعدادات النموذج (.onnx.json) مفقود: {path}",
        "err_config_read": "فشل قراءة ملف JSON للنموذج: {error}",
        "err_wav_missing": "لم يتم إنشاء ملف الصوت الناتج: {path}",
        "err_wav_empty": "ملف الصوت الناتج فارغ أو تالف ({size} بايت).",
        "err_wav_frames": "ملف WAV لا يحتوي على إطارات صوتية صالحة.",
        "err_wav_header": "ترويسة ملف WAV غير صالحة: {error}",
        "err_piper_permission": "ملف Piper لا يملك صلاحية التنفيذ (chmod +x): {path}",
        "status_piper_missing": "محرك Piper غير موجود في المسار: {path}",
        "status_files_incomplete": "ملفات النموذج (.onnx / .onnx.json) غير مكتملة في: {path}",
        "status_ready_detail": "النموذج جاهز ({rate} Hz | {speakers} متحدث)",
        "err_timeout": "تجاوزت عملية التوليد المهلة الزمنية ({seconds} ثانية).",
        "err_no_audio_loaded": "لا يوجد ملف صوتي محمّل حالياً.",
        "err_aplay_missing": "أداة aplay غير متوفرة على هذا النظام (ثبّت حزمة alsa-utils).",
        "err_piper_run": "تعذّر تشغيل محرك Piper: {error}",
        "err_piper_failed": "فشل محرك Piper (رمز الخطأ {code}): {error}",
        "err_unknown": "خطأ غير معروف",
        "err_speaker_range": "معرّف المتحدث ({sid}) خارج النطاق المتاح (0..{maximum}).",
        "validate_empty": "يرجى إدخال نص كورمانجي أولاً / Ji kerema xwe berê nivîsekê binivîse.",
        "validate_too_long": "النص طويل جداً ({count} حرف). الحد الأقصى المسموح هو {maximum} حرف.",
        "validate_symbols": "النص يحتوي على رموز فقط دون كلمات قابلة للنطق.",
        "err_export_no_wav": "لا يوجد ملف صوتي مولّد حالياً للحفظ.",
        # ------------------------------------------ settings-dialog fragments
        "input_label_primary": "النص الكورمانجي",
        "input_label_secondary": "(Nivîsa Kurmancî)",
        "settings_title_primary": "إعدادات",
        "settings_title_secondary": "Kurmanji-TTS",
        "model_label_primary": "مسار ملف النموذج",
        "model_label_secondary": "(.onnx)",
        "piper_label_primary": "مسار محرك",
        "piper_label_middle": "Piper",
        "piper_label_suffix": "التنفيذي",
        "settings_note_clean": "ملاحظة: يعمل التطبيق محلياً بالكامل على المعالج دون اتصال بالإنترنت.",
    },
    "ku": {
        # ------------------------------------------------------ window chrome
        "app_subtitle": "Nivîsê Kurmancî bikin deng - bi temamî herêmî (CPU)",
        "model_checking": "Model tê kontrolkirin...",
        "model_ready": "Model amade ye",
        "model_not_ready": "Model an motor ne amade ye",
        "close_notification": "Agahiyê bigire",
        # ----------------------------------------------------------- counters
        "label_chars": "Tîp:",
        "label_words": "Peyv:",
        "label_hawar": "Tîpên Hawarê yên hatine dîtin:",
        "label_samples": "Nimûneyên nivîsê yên bilez:",
        "clear_text": "Nivîsê paqij bike",
        "input_label": "Nivîsa Kurmancî",
        "input_hint": "Mînak: Rojbaş! Ez dixwazim bi zimanê kurdî biaxivim...",
        "voice_language": "Zimanê deng",
        "voice_language_tooltip": "Zimanê axaftinê hilbijêre: Kurmancî an Erebî",
        "input_label_ar": "Nivîsa Erebî",
        "input_hint_ar": "Nivîseke Erebî binivîse: مرحباً، كيف حالك؟",
        # ------------------------------------------------------------- engine
        "engine_profile": "Motorê deng",
        "engine_profile_tooltip": "Motorê çêkirinê û modela zimanê hilbijêre",
        "profile_piper_kmr": "Kurmancî — Piper (90 Speakers)",
        "profile_mms_kmr": "Kurmancî — Meta MMS",
        "profile_mms_ara": "العربية — Meta MMS",
        "mms_speaker_0": "MMS Speaker 0",
        "mms_arabic": "MMS Arabic",
        "err_sherpa_missing": "Pirtûkxaneya sherpa-onnx nehat dîtin: {error}",
        "err_sherpa_init": "Modela MMS nehat barkirin: {error}",
        "speaker": "Axêver",
        "speed": "Lez:",
        "speed_tooltip": "Leza axaftinê (0.50x hêdî — 1.50x bilez)",
        "generate": "Deng çêbike",
        "play": "Bilîze",
        "pause": "Rawestîne",
        "stop": "Bidawî bike",
        "save_wav": "WAV hilîne",
        # ------------------------------------------------------------- player
        "metric_gen": "Dema çêkirinê:",
        "metric_duration": "Dema deng:",
        "metric_rtf": "RTF:",
        "metric_rate": "Frekans:",
        "metric_speaker": "Axêver:",
        "language": "Ziman",
        "theme_tooltip": "Moda tarî / ronî biguherîne",
        "settings_tooltip": "Mîhengên model û motorê",
        "error_no_audio": "Tu pelê dengî yê amade tune ye.",
        "error_play": "Deng di nava sepanê de nehat lêxistin: {error}",
        "error_seek": "Cihê deng nehat guhertin: {error}",
        "error_save_first": "Berî qeydkirinê deng çêbike.",
        "save_dialog_title": "Pelê dengî qeyd bike (WAV)",
        "save_ok": "Pelê dengî hat qeydkirin: {name}",
        "save_failed": "Pelê WAV nehat qeydkirin: {error}",
        "engine_hint": "setup_runtime.py bixebitîne an jî rêyan ji mîhengan rast bike.",
        "load_in_app_failed": "Deng di lîstikvanê hundirîn de nehat barkirin: {error}",
        "generate_ok": "Deng bi serkeftî hat çêkirin!",
        "generate_failed": "Di dema çêkirina deng de xeletiyek çêbû: {error}",
        "settings_title": "Mîhengên Kurmanji-TTS",
        "model_path_label": "Rêya pelê modelê (.onnx)",
        "piper_path_label": "Rêya motorê Piper",
        "pick_model": "Pelê modelê hilbijêre (.onnx)",
        "pick_piper": "Motorê Piper hilbijêre",
        "browse_model": "Pelê modelê bigere",
        "browse_piper": "Motorê Piper bigere",
        "persistent": "Modelê di bîrê de bihêle (çêkirina bilez bê barkirina nû)",
        "settings_note": "Têbînî: sepan bi tevahî herêmî li ser CPU-ê dixebite, bê înternet.",
        "cancel": "Betal",
        "save_settings": "Mîhengan qeyd bike",
        # --------------------------------------------------- errors and status
        "err_model_missing": "Pelê modelê nehat dîtin: {path}",
        "err_config_missing": "Pelê mîhengên modelê (.onnx.json) tune ye: {path}",
        "err_config_read": "Xwendina JSON a modelê têk çû: {error}",
        "err_wav_missing": "Pelê dengî yê encamê nehat çêkirin: {path}",
        "err_wav_empty": "Pelê dengî vala an jî xera ye ({size} bayt).",
        "err_wav_frames": "Pelê WAV çarçoveyên dengî yên derbasdar tune ye.",
        "err_wav_header": "Serdêrîya pelê WAV ne derbasdar e: {error}",
        "err_piper_permission": "Destûra xebitandinê ya Piper tune ye (chmod +x): {path}",
        "status_piper_missing": "Motorê Piper li vê rêyê tune ye: {path}",
        "status_files_incomplete": "Pelên modelê (.onnx / .onnx.json) temam nînin: {path}",
        "status_ready_detail": "Model amade ye ({rate} Hz | {speakers} axêver)",
        "err_timeout": "Çêkirina deng ji demê derbas bû ({seconds} saniye).",
        "err_no_audio_loaded": "Ti pelê dengî nehatiye barkirin.",
        "err_aplay_missing": "aplay li ser vê pergalê nehatiye sazkirin (alsa-utils saz bike).",
        "err_piper_run": "Motorê Piper nehat xebitandin: {error}",
        "err_piper_failed": "Motorê Piper têk çû (koda xeletiyê {code}): {error}",
        "err_unknown": "Xeletiya nenas",
        "err_speaker_range": "Nasnameya axêverê ({sid}) di derveyî rêjeyê de ye (0..{maximum}).",
        "validate_empty": "Ji kerema xwe berê nivîsekê binivîse.",
        "validate_too_long": "Nivîs pir dirêj e ({count} tîp). Sînor {maximum} tîp e.",
        "validate_symbols": "Nivîs tenê nîşane ye û peyvên bilêvkirinê tune ne.",
        "err_export_no_wav": "Tu pelê dengî yê çêkirî tune ye bo qeydkirinê.",
        # ------------------------------------------ settings-dialog fragments
        "input_label_primary": "Nivîsa Kurmancî",
        "input_label_secondary": "",
        "settings_title_primary": "Mîhengên Kurmanji-TTS",
        "settings_title_secondary": "",
        "model_label_primary": "Rêya pelê modelê (.onnx)",
        "model_label_secondary": "",
        "piper_label_primary": "Rêya motorê Piper",
        "piper_label_middle": "",
        "piper_label_suffix": "",
        "settings_note_clean": "Têbînî: sepan bi tevahî herêmî li ser CPU-ê dixebite, bê înternet.",
    },
    "en": {
        # ------------------------------------------------------ window chrome
        "app_subtitle": "Offline Kurmanji Neural Text-to-Speech (CPU)",
        "model_checking": "Checking model...",
        "model_ready": "Model Ready",
        "model_not_ready": "Model or engine not ready",
        "close_notification": "Dismiss notification",
        # ----------------------------------------------------------- counters
        "label_chars": "Characters:",
        "label_words": "Words:",
        "label_hawar": "Hawar letters found:",
        "label_samples": "Quick text samples:",
        "clear_text": "Clear text",
        "input_label": "Kurmanji text (Nivîsa Kurmancî)",
        "input_hint": "Mînak: Rojbaş! Ez dixwazim bi zimanê kurdî biaxivim...",
        "voice_language": "Voice language",
        "voice_language_tooltip": "Choose the speech language: Kurmanji or Arabic",
        "input_label_ar": "Arabic text",
        "input_hint_ar": "Type Arabic text: مرحباً، كيف حالك؟",
        # ------------------------------------------------------------- engine
        "engine_profile": "Voice engine",
        "engine_profile_tooltip": "Choose the synthesis engine and language model",
        "profile_piper_kmr": "Kurmancî — Piper (90 Speakers)",
        "profile_mms_kmr": "Kurmancî — Meta MMS",
        "profile_mms_ara": "العربية — Meta MMS",
        "mms_speaker_0": "MMS Speaker 0",
        "mms_arabic": "MMS Arabic",
        "err_sherpa_missing": "sherpa-onnx is not installed: {error}",
        "err_sherpa_init": "Failed to load the MMS model: {error}",
        "speaker": "Speaker",
        "speed": "Speed:",
        "speed_tooltip": "Speech speed (0.50x slow - 1.50x fast)",
        "generate": "Generate Speech",
        "play": "Play",
        "pause": "Pause",
        "stop": "Stop",
        "save_wav": "Save WAV",
        # ------------------------------------------------------------- player
        "metric_gen": "Generation time:",
        "metric_duration": "Audio duration:",
        "metric_rtf": "RTF:",
        "metric_rate": "Sample rate:",
        "metric_speaker": "Speaker:",
        "language": "Language",
        "theme_tooltip": "Toggle dark / light mode",
        "settings_tooltip": "Model and engine settings",
        "error_no_audio": "No audio file is ready to play.",
        "error_play": "Could not play audio inside the app: {error}",
        "error_seek": "Could not seek in the audio: {error}",
        "error_save_first": "Generate speech before saving.",
        "save_dialog_title": "Save audio file (WAV)",
        "save_ok": "Audio file saved successfully: {name}",
        "save_failed": "Could not save WAV file: {error}",
        "engine_hint": "Run setup_runtime.py or set the paths in Settings.",
        "load_in_app_failed": "Could not load audio in the in-app player: {error}",
        "generate_ok": "Speech generated successfully!",
        "generate_failed": "Unexpected error during generation: {error}",
        "settings_title": "Kurmanji-TTS Settings",
        "model_path_label": "Model file path (.onnx)",
        "piper_path_label": "Piper executable path",
        "pick_model": "Select model file (.onnx)",
        "pick_piper": "Select Piper executable",
        "browse_model": "Browse model file",
        "browse_piper": "Browse Piper executable",
        "persistent": "Keep the model loaded in memory (faster generation, no reload)",
        "settings_note": "Note: the app runs fully locally on CPU, without internet access.",
        "cancel": "Cancel",
        "save_settings": "Save settings",
        # --------------------------------------------------- errors and status
        "err_model_missing": "Model file not found: {path}",
        "err_config_missing": "Model config (.onnx.json) not found: {path}",
        "err_config_read": "Could not read the model JSON: {error}",
        "err_wav_missing": "Output WAV file was not created: {path}",
        "err_wav_empty": "Output audio file is empty or corrupt ({size} bytes).",
        "err_wav_frames": "WAV file contains no valid audio frames.",
        "err_wav_header": "Invalid WAV header: {error}",
        "err_piper_permission": "Piper is not executable (chmod +x): {path}",
        "status_piper_missing": "Piper engine not found at: {path}",
        "status_files_incomplete": "Model files (.onnx / .onnx.json) incomplete in: {path}",
        "status_ready_detail": "Model Ready ({rate} Hz | {speakers} speakers)",
        "err_timeout": "Speech generation timed out ({seconds} seconds).",
        "err_no_audio_loaded": "No audio file is currently loaded.",
        "err_aplay_missing": "aplay is not installed on this system (install alsa-utils).",
        "err_piper_run": "Could not start the Piper engine: {error}",
        "err_piper_failed": "Piper engine failed (error code {code}): {error}",
        "err_unknown": "unknown error",
        "err_speaker_range": "Speaker id ({sid}) is out of range (0..{maximum}).",
        "validate_empty": "Please enter some Kurmanji text first.",
        "validate_too_long": "Text is too long ({count} characters). Maximum allowed is {maximum}.",
        "validate_symbols": "The text contains only symbols with no pronounceable words.",
        "err_export_no_wav": "No generated audio file is available to save.",
        # ------------------------------------------ settings-dialog fragments
        "input_label_primary": "Kurmanji text",
        "input_label_secondary": "(Nivîsa Kurmancî)",
        "settings_title_primary": "Kurmanji-TTS Settings",
        "settings_title_secondary": "",
        "model_label_primary": "Model file path (.onnx)",
        "model_label_secondary": "",
        "piper_label_primary": "Piper executable path",
        "piper_label_middle": "",
        "piper_label_suffix": "",
        "settings_note_clean": "Note: the app runs fully locally on CPU, without internet access.",
    },
}


def is_rtl(lang: str) -> bool:
    """Return True for right-to-left interface languages."""
    return lang in RTL_LANGUAGES


def tr(lang: str, key: str, **kwargs: object) -> str:
    """Translate a key, falling back to Arabic then English, and format placeholders."""
    template = TRANSLATIONS.get(lang, {}).get(key)
    if template is None:
        template = TRANSLATIONS["ar"].get(key, TRANSLATIONS["en"].get(key, key))
    if kwargs:
        try:
            return template.format(**kwargs)
        except (KeyError, ValueError, IndexError):
            return template
    return template


_current_language = "ar"


def set_current_language(lang: str) -> None:
    """Set the process-wide language used by engine and validation messages."""
    global _current_language
    _current_language = lang if lang in SUPPORTED_LANGUAGES else "ar"


def current_language() -> str:
    return _current_language


def msg(key: str, **kwargs: object) -> str:
    """Translate using the process-wide language (for non-UI modules)."""
    return tr(_current_language, key, **kwargs)
